﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebBanSachMVC.Models;
namespace WebBanSachMVC.Models
{
    public class GioHang
    {
        BANNUOCHOAEntities1 db= new BANNUOCHOAEntities1();
        public int iMaSP { get; set; }
        public string TenSP { get; set; }
        public string HinhAnh { get; set; }
        public double DonGia { get; set; }
        public int SoLuong { get; set; }
        public double ThanhTien
        {
            get { return SoLuong * DonGia; }
        }
        public GioHang(int MaSP) {
            nuochoa nh=db.nuochoas.SingleOrDefault(n=>n.MaNH==MaSP);
            iMaSP = MaSP;
            TenSP = nh.TenNH;
            HinhAnh = nh.HinhMinhHoa;
            SoLuong = 1;
            DonGia = double.Parse(nh.DonGia.ToString());
            
        }
    }
}