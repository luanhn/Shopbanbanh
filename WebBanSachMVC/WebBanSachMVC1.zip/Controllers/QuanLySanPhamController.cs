﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanSachMVC.Models;
using PagedList;
// using thu vien de luu anh?
using System.IO;
namespace WebBanSachMVC.Controllers
{
    public class QuanLySanPhamController : Controller
    {
        BANNUOCHOAEntities1 db = new BANNUOCHOAEntities1();
        //
        // GET: /QuanLySanPham/
        public ActionResult Index(int? page)
        {
            int pagesize = 5;
            int pagenumber = (page??1);

            return View(db.nuochoas.ToList().ToPagedList(pagenumber,pagesize));
        }
        //them moi san pham cua admin
        [HttpGet]
        public ActionResult ThemMoi() {
            //dua du lieu vao drodownlist
            ViewBag.MaTheLoai = new SelectList( db.theloais.ToList(),"MaTheLoai","TenTheLoai");
            ViewBag.MaNSX = new SelectList( db.nhasanxuats.ToList(),"MaNSX","TenNSX");
          
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult ThemMoi(nuochoa nh,HttpPostedFileBase fileUpload) {
            //luu ten cua file
          
            ViewBag.MaTheLoai = new SelectList(db.theloais.ToList(), "MaTheLoai", "TenTheLoai");
            ViewBag.MaNSX = new SelectList(db.nhasanxuats.ToList(), "MaNSX", "TenNSX");
            //them vao csdl
            if (ModelState.IsValid) {
                var fileName = Path.GetFileName(fileUpload.FileName);
                //luu duong dan cua file
                var path = Path.Combine(Server.MapPath("~/Hinhsanpham"), fileName);
                if (System.IO.File.Exists(path))
                {
                    ViewBag.ThongBao = "Hình ảnh đã tồn tại";

                }
                else
                {
                    fileUpload.SaveAs(path);
                }
                //luu ten hinh vo csdl
                ViewBag.ThongbaoOK = "Thêm thành công";
                nh.HinhMinhHoa = fileUpload.FileName;
                db.nuochoas.Add(nh);
                    db.SaveChanges();

            }
            return View();
        }
        [HttpGet]
        public ActionResult ChinhSua(int MaSP) 
        {
           
            nuochoa nh = db.nuochoas.SingleOrDefault(n => n.MaNH == MaSP);
            if (nh == null) {
                Response.StatusCode = 404;
                return null;
            }
            ViewBag.MaTheLoai = new SelectList(db.theloais.ToList(), "MaTheLoai", "TenTheLoai",nh.MaTheLoai);
            ViewBag.MaNSX = new SelectList(db.nhasanxuats.ToList(), "MaNSX", "TenNSX",nh.MaNSX);
            return View(nh);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult ChinhSua(nuochoa nh,FormCollection f) {
            //nuochoa nh1 = db.nuochoas.SingleOrDefault(n => n.MaNH == nh.MaNH);
            //nh1.MoTa = nh.MoTa;
            //db.SaveChanges();
           
            if (ModelState.IsValid) {
                //thuc hien cap nhat trong model
                db.Entry(nh).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }

            ViewBag.MaTheLoai = new SelectList(db.theloais.ToList(), "MaTheLoai", "TenTheLoai",nh.MaTheLoai);
            ViewBag.MaNSX = new SelectList(db.nhasanxuats.ToList(), "MaNSX", "TenNSX",nh.MaNSX);
             
            return RedirectToAction("Index");
        }
        //hien thi cua admin
        public ActionResult HienThi(int MaSP) {
            nuochoa nh = db.nuochoas.SingleOrDefault(n => n.MaNH == MaSP);
            if(nh==null){
                Response.StatusCode = 404;
                return null;
            }
            return View(nh);
        
        }
        //xoa san pham admin
        [HttpGet]
        public ActionResult Xoa(int MaSP) {
            nuochoa nh = db.nuochoas.SingleOrDefault(n => n.MaNH == MaSP);
            if (nh == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(nh);
        }
        [HttpPost,ActionName("Xoa")]
        public ActionResult XacNhanXoa(int MaSP) 
        {
            nuochoa nh = db.nuochoas.SingleOrDefault(n=>n.MaNH==MaSP);
            if (nh == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            db.nuochoas.Remove(nh);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        //quan li khac hang
        public ActionResult QuanLyKhachHang() 
        {
            return View(db.KHACHHANGs.ToList()); 
        }
        [HttpGet]
        public ActionResult ChinhSuaKH(int MaKH)
        {
            KHACHHANG kh = db.KHACHHANGs.SingleOrDefault(n => n.MaKH == MaKH);
            if (kh == null) {
                Response.StatusCode = 404;
                return null;
            }
            return View(kh);
        }
        [HttpPost]
        public ActionResult ChinhSuaKH(KHACHHANG kh)
        {
            if (ModelState.IsValid) {
                db.Entry(kh).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
            return RedirectToAction("QuanLyKhachHang");
        }
        //xoa khah hang
        [HttpGet]
        public ActionResult XoaKH(int MaKH) {
            KHACHHANG kh = db.KHACHHANGs.SingleOrDefault(n => n.MaKH == MaKH);
            if (kh == null) 
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(kh);
        }
        [HttpPost,ActionName("XoaKH")]
        public ActionResult XacNhanXoaKH(int MaKH)
        {
            KHACHHANG kh = db.KHACHHANGs.SingleOrDefault(n => n.MaKH == MaKH);
            if (kh == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            db.KHACHHANGs.Remove(kh);
            db.SaveChanges();
            return RedirectToAction("QuanLyKhachHang");
        }
	}
}