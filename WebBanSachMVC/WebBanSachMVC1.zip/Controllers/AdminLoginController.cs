﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanSachMVC.Models;
namespace WebBanSachMVC.Controllers
{
    public class AdminLoginController : Controller
    {BANNUOCHOAEntities1 db=new BANNUOCHOAEntities1();
        //
        // GET: /AdminLogin/
       
        [HttpGet]
    public ActionResult Index()
    {
            return View();
        }
        [HttpPost]
        public ActionResult Index(FormCollection f)
        {
            string tendn = f["txttaikhoan"].ToString();
            string mk = f["txtmatkhau"].ToString();
            AD admin = db.ADs.SingleOrDefault(n => n.TenDNAdmin == tendn && n.MatKhauAdmin == mk);
            if(admin!=null)
            {
                ViewBag.ThongBao = "Đăng nhập thành công";
                return RedirectToAction("Index", "QuanLySanPham");
            }
            ViewBag.ThongBao = "Đăng nhập thất bại";
            return View();
        }
	}
}