﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanSachMVC.Models;

namespace WebBanSachMVC.Controllers
{
    public class SachmoiController : Controller
    {
        BANNUOCHOAEntities1 db = new BANNUOCHOAEntities1();
        //
        // GET: /Sachmoi/
        public ActionResult SachmoiPartial()
        {
            return PartialView(db.nuochoas.Take(3).ToList());
        }
        public ViewResult xemchitiet(int manh=0) {
            nuochoa nh = db.nuochoas.SingleOrDefault(n => n.MaNH == manh);
            if (nh == null) {
                Response.StatusCode = 404;
                return null;
            }
            ViewBag.TenTheLoai = db.theloais.Single(n => n.MaTheLoai == nh.MaTheLoai).TenTheLoai;
            return View(nh);
            
        }
	}
}