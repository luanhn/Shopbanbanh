﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanSachMVC.Models;
using PagedList;
using PagedList.Mvc;
namespace WebBanSachMVC.Controllers
{
    public class NhaxuatbanController : Controller
    {
        BANNUOCHOAEntities1 db = new BANNUOCHOAEntities1();
        //
        // GET: /Nhaxuatban/
        public ActionResult nhaxuatbanpartial()
        {
            return PartialView(db.nhasanxuats.ToList());
        }
        public ViewResult sachtheonhaxuatban(int? page, int manxb=0) {

            ViewBag.manxb = manxb;
            int pagesize = 4;
            int pagenumber = 1;
            nhasanxuat nxb = db.nhasanxuats.SingleOrDefault(n => n.MaNSX == manxb);
            if (nxb == null) {
                Response.StatusCode = 404;
                return null;
            }
            List<nuochoa> nh = db.nuochoas.Where(n => n.MaNSX == manxb).ToList();
            if (nh.Count == 0)
            {
                ViewBag.nuochoa = "k co sach nao thuoc nxb nay";
            }
            ViewBag.ThongBao = db.nhasanxuats.Single(n => n.MaNSX == manxb).TenNSX;
            return View(nh.ToList().ToPagedList(pagenumber,pagesize));
        }
        public ViewResult xemchitiet(int manh=0) {
            nuochoa nh = db.nuochoas.SingleOrDefault(n => n.MaNH == manh);
            if (nh == null) {
                Response.StatusCode = 404;
                return null;
            }
            return View(nh);
        }
	}
}