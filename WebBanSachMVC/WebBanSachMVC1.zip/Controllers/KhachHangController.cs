﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanSachMVC.Models;
using System.ComponentModel.DataAnnotations;
namespace WebBanSachMVC.Controllers
{
    public class KhachHangController : Controller
    {
        BANNUOCHOAEntities1 db = new BANNUOCHOAEntities1();
        //
        // GET: /KhachHang/
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Dangky() {
            return View();
        }
        [HttpPost]
        public ActionResult Dangky(KHACHHANG kh)
        {
            if (ModelState.IsValid) {
                db.KHACHHANGs.Add(kh);
                db.SaveChanges();
            }
            return View();
        }
        [HttpGet]
        public ActionResult Dangnhap() {
            return View();
        }
        [HttpPost]
        public ActionResult Dangnhap(FormCollection f) {
            string tk = f["txttaikhoan"].ToString();
            string mk = f["txtmatkhau"].ToString();
            KHACHHANG kh = db.KHACHHANGs.SingleOrDefault(n => n.TenDN == tk && n.MatKhau == mk);
            if (kh != null)
            {
                ViewBag.ThongBao = "Thanh cong";
                Session["TenDN"] = kh;
                return View();
            }
            
                ViewBag.ThongBao = "That bai";
            return View();
        }
        
	}
}